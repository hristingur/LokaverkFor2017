﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Lokaverkefni
{
    class gagnagrunnur
    {
        //server: Segir til um hvar serverinn er hýstur, hjá okkur er það localhost
        private string server;
        //database: nafnið á gagnagrunninum sem verið er að nota
        private string database;
        // uid:er MySQL Notendanafnið 
        private string uid;
        //password: er MySQL lykilorðið
        private string password;
        //tengistrengur: contains the connection string to connect to the database
        //and will be assigned to the connection variable.
        string tengistrengur = null;
        //fyrirspurn: inniheldur viðeigandi fyrispurn hverju sinni
        string fyrirspurn = null;

        MySqlConnection sqltenging; //þetta er notað til þess að opna tengingu við gagnagrunn
        MySqlCommand nySQLskipun; // Þetta er notað til þess að framkvæma SQL fyrirspurnina
        MySqlDataReader sqllesari = null; //Lesari sem getur lesið úr SQL gagnagrunninum

        /*Þessi aðferð tengir notanda við gagnagrunninn,
         * þannig að þið breytið viðeigandi upplýsingum sem á við */
        public void TengingVidGagnagrunn()
        {
            server = "10.200.10.24";
            database = "2608993339_hopverkefni"; // hér setjið þið ykkar kennitölu
            uid = "2608993339";
            password = "mypassword";

            tengistrengur = "server=" + server + ";userid=" + uid + ";password=" + password + ";database=" + database;
            sqltenging = new MySqlConnection(tengistrengur);
        }//endir á tengingvidgagnagrunn

        /*þessi aðferð athugar hvort tenging sé komin á eða ekki */
        private bool OpenConnection()
        {
            try
            {
                sqltenging.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
        }//endir á bool OpenConnection

        /*Þessi aðferð lokar tengingu eftir notkun */
        private bool CloseConnection()
        {
            try
            {
                sqltenging.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
        }

        /*Þessi aðferð les úr SQL gagnagrunni allar færslur og birtir í viðeigandi töflu*/
        public List<string> LesautSQLToflu()
        {
            List<string> Faerslur = new List<string>();

            string lina = null;

            if (OpenConnection() == true)
            {
                fyrirspurn = "SELECT * FROM hopverkefni";
                nySQLskipun = new MySqlCommand(fyrirspurn, sqltenging);
                /*ExecuteReader: Used to execute a command that will return 0 or more records*/
                sqllesari = nySQLskipun.ExecuteReader();

                while (sqllesari.Read())
                {
                    for (int i = 0; i < sqllesari.FieldCount; i++)
                    {
                        lina += (sqllesari.GetValue(i).ToString()) + ":";
                    }
                    Faerslur.Add(lina);
                    lina = null;
                }
                CloseConnection();
                return Faerslur;
            }
            return Faerslur;
        }//Endir á LesautSQLToflu

        public List<string> GetID()
        {
            List<string> Faerslur = new List<string>();

            string lina = null;

            if (OpenConnection() == true)
            {
                fyrirspurn = "SELECT id FROM hopverkefni";
                nySQLskipun = new MySqlCommand(fyrirspurn, sqltenging);
                /*ExecuteReader: Used to execute a command that will return 0 or more records*/
                sqllesari = nySQLskipun.ExecuteReader();

                while (sqllesari.Read())
                {
                    for (int i = 0; i < sqllesari.FieldCount; i++)
                    {
                        lina += (sqllesari.GetValue(i).ToString());
                    }
                    Faerslur.Add(lina);
                    lina = null;
                }
                CloseConnection();
                return Faerslur;
            }
            return Faerslur;
        }//Endir á LesautSQLToflu


        /*Þessi aðferð les úr SQL gagnagrunni þyngd hrútsins og birtir*/
        public string LesautSQLFlokk(int id)
        {
            List<string> Faerslur = new List<string>();

            string lina = null;

            if (OpenConnection() == true)
            {
                fyrirspurn = "SELECT * FROM hopverkefni where id="+id;
                nySQLskipun = new MySqlCommand(fyrirspurn, sqltenging);
                /*ExecuteReader: Used to execute a command that will return 0 or more records*/
                sqllesari = nySQLskipun.ExecuteReader();

                while (sqllesari.Read())
                {
                    for (int i = 0; i < sqllesari.FieldCount; i++)
                    {
                        lina += (sqllesari.GetValue(i).ToString()) + ":";
                    }
                   
                }
                CloseConnection();
                return lina;
            }
            return lina;
        }//Endir á LesautSQLWeight

       
    } // endir a class gagnagrunnur
}// endir a namespace
