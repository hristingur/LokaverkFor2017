﻿namespace Lokaverkefni
{
    partial class oneplayer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(oneplayer));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnDragaSpil = new System.Windows.Forms.Button();
            this.panComputer = new System.Windows.Forms.Panel();
            this.panPlayer = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnÞyngd = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblLeidbeiningar = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Diamond-1.gif");
            this.imageList1.Images.SetKeyName(1, "Diamond-2.gif");
            this.imageList1.Images.SetKeyName(2, "Diamond-3.gif");
            this.imageList1.Images.SetKeyName(3, "Diamond-4.gif");
            this.imageList1.Images.SetKeyName(4, "Diamond-5.gif");
            this.imageList1.Images.SetKeyName(5, "Diamond-6.gif");
            this.imageList1.Images.SetKeyName(6, "Diamond-7.gif");
            this.imageList1.Images.SetKeyName(7, "Diamond-8.gif");
            this.imageList1.Images.SetKeyName(8, "Diamond-9.gif");
            this.imageList1.Images.SetKeyName(9, "Diamond-10.gif");
            this.imageList1.Images.SetKeyName(10, "Diamond-Jack.gif");
            this.imageList1.Images.SetKeyName(11, "Diamond-Queen.gif");
            this.imageList1.Images.SetKeyName(12, "Diamond-King.gif");
            this.imageList1.Images.SetKeyName(13, "Heart-1.gif");
            this.imageList1.Images.SetKeyName(14, "Heart-2.gif");
            this.imageList1.Images.SetKeyName(15, "Heart-3.gif");
            this.imageList1.Images.SetKeyName(16, "Heart-4.gif");
            this.imageList1.Images.SetKeyName(17, "Heart-5.gif");
            this.imageList1.Images.SetKeyName(18, "Heart-6.gif");
            this.imageList1.Images.SetKeyName(19, "Heart-7.gif");
            this.imageList1.Images.SetKeyName(20, "Heart-8.gif");
            this.imageList1.Images.SetKeyName(21, "Heart-9.gif");
            this.imageList1.Images.SetKeyName(22, "Heart-10.gif");
            this.imageList1.Images.SetKeyName(23, "Heart-Jack.gif");
            this.imageList1.Images.SetKeyName(24, "Heart-Queen.gif");
            this.imageList1.Images.SetKeyName(25, "Heart-King.gif");
            this.imageList1.Images.SetKeyName(26, "Leaf-1.gif");
            this.imageList1.Images.SetKeyName(27, "Leaf-2.gif");
            this.imageList1.Images.SetKeyName(28, "Leaf-3.gif");
            this.imageList1.Images.SetKeyName(29, "Leaf-4.gif");
            this.imageList1.Images.SetKeyName(30, "Leaf-5.gif");
            this.imageList1.Images.SetKeyName(31, "Leaf-6.gif");
            this.imageList1.Images.SetKeyName(32, "Leaf-7.gif");
            this.imageList1.Images.SetKeyName(33, "Leaf-8.gif");
            this.imageList1.Images.SetKeyName(34, "Leaf-9.gif");
            this.imageList1.Images.SetKeyName(35, "Leaf-10.gif");
            this.imageList1.Images.SetKeyName(36, "Leaf-Jack.gif");
            this.imageList1.Images.SetKeyName(37, "Leaf-Queen.gif");
            this.imageList1.Images.SetKeyName(38, "Leaf-King.gif");
            this.imageList1.Images.SetKeyName(39, "Spade-1.gif");
            this.imageList1.Images.SetKeyName(40, "Spade-2.gif");
            this.imageList1.Images.SetKeyName(41, "Spade-3.gif");
            this.imageList1.Images.SetKeyName(42, "Spade-4.gif");
            this.imageList1.Images.SetKeyName(43, "Spade-5.gif");
            this.imageList1.Images.SetKeyName(44, "Spade-6.gif");
            this.imageList1.Images.SetKeyName(45, "Spade-7.gif");
            this.imageList1.Images.SetKeyName(46, "Spade-8.gif");
            this.imageList1.Images.SetKeyName(47, "Spade-9.gif");
            this.imageList1.Images.SetKeyName(48, "Spade-10.gif");
            this.imageList1.Images.SetKeyName(49, "Spade-Jack.gif");
            this.imageList1.Images.SetKeyName(50, "Spade-Queen.gif");
            this.imageList1.Images.SetKeyName(51, "Spade-King.gif");
            // 
            // btnDragaSpil
            // 
            this.btnDragaSpil.Location = new System.Drawing.Point(375, 479);
            this.btnDragaSpil.Name = "btnDragaSpil";
            this.btnDragaSpil.Size = new System.Drawing.Size(261, 58);
            this.btnDragaSpil.TabIndex = 0;
            this.btnDragaSpil.Text = "Draga Spil";
            this.btnDragaSpil.UseVisualStyleBackColor = true;
            this.btnDragaSpil.Click += new System.EventHandler(this.btnDragaSpil_Click);
            // 
            // panComputer
            // 
            this.panComputer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panComputer.Location = new System.Drawing.Point(715, 105);
            this.panComputer.Name = "panComputer";
            this.panComputer.Size = new System.Drawing.Size(261, 347);
            this.panComputer.TabIndex = 1;
            // 
            // panPlayer
            // 
            this.panPlayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panPlayer.Location = new System.Drawing.Point(46, 105);
            this.panPlayer.Name = "panPlayer";
            this.panPlayer.Size = new System.Drawing.Size(261, 347);
            this.panPlayer.TabIndex = 2;
            // 
            // button9
            // 
            this.button9.Image = global::Lokaverkefni.Properties.Resources.Malireinkun1;
            this.button9.Location = new System.Drawing.Point(880, 12);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(96, 87);
            this.button9.TabIndex = 9;
            this.button9.Text = "Rass";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Image = global::Lokaverkefni.Properties.Resources.Mjolk1;
            this.button8.Location = new System.Drawing.Point(178, 12);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(96, 87);
            this.button8.TabIndex = 8;
            this.button8.Text = "Mjólk";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Image = global::Lokaverkefni.Properties.Resources.Ullareinkun1;
            this.button7.Location = new System.Drawing.Point(305, 12);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(91, 87);
            this.button7.TabIndex = 7;
            this.button7.Text = "Ull";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Image = global::Lokaverkefni.Properties.Resources.Afkvaemi1;
            this.button6.Location = new System.Drawing.Point(418, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(89, 87);
            this.button6.TabIndex = 6;
            this.button6.Text = "Afkvæmi";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Image = global::Lokaverkefni.Properties.Resources.LærisEinkun2;
            this.button5.Location = new System.Drawing.Point(527, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(98, 87);
            this.button5.TabIndex = 5;
            this.button5.Text = "Læri";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Image = global::Lokaverkefni.Properties.Resources.Frjosemi1;
            this.button4.Location = new System.Drawing.Point(647, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(97, 87);
            this.button4.TabIndex = 4;
            this.button4.Text = "Frjósemi";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Image = global::Lokaverkefni.Properties.Resources.ÞykktBakvöðva2;
            this.button3.Location = new System.Drawing.Point(769, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 87);
            this.button3.TabIndex = 3;
            this.button3.Text = "Hryggur";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btnÞyngd
            // 
            this.btnÞyngd.Image = global::Lokaverkefni.Properties.Resources.Kiloþyngd1;
            this.btnÞyngd.Location = new System.Drawing.Point(46, 12);
            this.btnÞyngd.Name = "btnÞyngd";
            this.btnÞyngd.Size = new System.Drawing.Size(101, 87);
            this.btnÞyngd.TabIndex = 0;
            this.btnÞyngd.Text = "Þyngd";
            this.btnÞyngd.UseVisualStyleBackColor = true;
            this.btnÞyngd.Click += new System.EventHandler(this.btnÞyngd_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(342, 105);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(333, 198);
            this.richTextBox1.TabIndex = 10;
            this.richTextBox1.Text = "";
            // 
            // lblLeidbeiningar
            // 
            this.lblLeidbeiningar.AutoSize = true;
            this.lblLeidbeiningar.Location = new System.Drawing.Point(398, 324);
            this.lblLeidbeiningar.Name = "lblLeidbeiningar";
            this.lblLeidbeiningar.Size = new System.Drawing.Size(214, 13);
            this.lblLeidbeiningar.TabIndex = 11;
            this.lblLeidbeiningar.Text = "Veldu flokk til að keppa í og dragðu svo spil";
            // 
            // oneplayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1071, 579);
            this.Controls.Add(this.lblLeidbeiningar);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnÞyngd);
            this.Controls.Add(this.panPlayer);
            this.Controls.Add(this.panComputer);
            this.Controls.Add(this.btnDragaSpil);
            this.Name = "oneplayer";
            this.Text = " nvg";
            this.Load += new System.EventHandler(this.oneplayer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnDragaSpil;
        private System.Windows.Forms.Panel panComputer;
        private System.Windows.Forms.Panel panPlayer;
        private System.Windows.Forms.Button btnÞyngd;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblLeidbeiningar;
    }
}