﻿namespace Lokaverkefni
{
    partial class oneplayer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(oneplayer));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnDragaSpil = new System.Windows.Forms.Button();
            this.panComputer = new System.Windows.Forms.Panel();
            this.panPlayer = new System.Windows.Forms.Panel();
            this.btnRass = new System.Windows.Forms.Button();
            this.btnMjolk = new System.Windows.Forms.Button();
            this.btnUll = new System.Windows.Forms.Button();
            this.btnAfkvaemi = new System.Windows.Forms.Button();
            this.btnLaeri = new System.Windows.Forms.Button();
            this.btnFrjosemi = new System.Windows.Forms.Button();
            this.btnHryggur = new System.Windows.Forms.Button();
            this.btnÞyngd = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblLeidbeiningar = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Diamond-1.gif");
            this.imageList1.Images.SetKeyName(1, "Diamond-2.gif");
            this.imageList1.Images.SetKeyName(2, "Diamond-3.gif");
            this.imageList1.Images.SetKeyName(3, "Diamond-4.gif");
            this.imageList1.Images.SetKeyName(4, "Diamond-5.gif");
            this.imageList1.Images.SetKeyName(5, "Diamond-6.gif");
            this.imageList1.Images.SetKeyName(6, "Diamond-7.gif");
            this.imageList1.Images.SetKeyName(7, "Diamond-8.gif");
            this.imageList1.Images.SetKeyName(8, "Diamond-9.gif");
            this.imageList1.Images.SetKeyName(9, "Diamond-10.gif");
            this.imageList1.Images.SetKeyName(10, "Diamond-Jack.gif");
            this.imageList1.Images.SetKeyName(11, "Diamond-Queen.gif");
            this.imageList1.Images.SetKeyName(12, "Diamond-King.gif");
            this.imageList1.Images.SetKeyName(13, "Heart-1.gif");
            this.imageList1.Images.SetKeyName(14, "Heart-2.gif");
            this.imageList1.Images.SetKeyName(15, "Heart-3.gif");
            this.imageList1.Images.SetKeyName(16, "Heart-4.gif");
            this.imageList1.Images.SetKeyName(17, "Heart-5.gif");
            this.imageList1.Images.SetKeyName(18, "Heart-6.gif");
            this.imageList1.Images.SetKeyName(19, "Heart-7.gif");
            this.imageList1.Images.SetKeyName(20, "Heart-8.gif");
            this.imageList1.Images.SetKeyName(21, "Heart-9.gif");
            this.imageList1.Images.SetKeyName(22, "Heart-10.gif");
            this.imageList1.Images.SetKeyName(23, "Heart-Jack.gif");
            this.imageList1.Images.SetKeyName(24, "Heart-Queen.gif");
            this.imageList1.Images.SetKeyName(25, "Heart-King.gif");
            this.imageList1.Images.SetKeyName(26, "Leaf-1.gif");
            this.imageList1.Images.SetKeyName(27, "Leaf-2.gif");
            this.imageList1.Images.SetKeyName(28, "Leaf-3.gif");
            this.imageList1.Images.SetKeyName(29, "Leaf-4.gif");
            this.imageList1.Images.SetKeyName(30, "Leaf-5.gif");
            this.imageList1.Images.SetKeyName(31, "Leaf-6.gif");
            this.imageList1.Images.SetKeyName(32, "Leaf-7.gif");
            this.imageList1.Images.SetKeyName(33, "Leaf-8.gif");
            this.imageList1.Images.SetKeyName(34, "Leaf-9.gif");
            this.imageList1.Images.SetKeyName(35, "Leaf-10.gif");
            this.imageList1.Images.SetKeyName(36, "Leaf-Jack.gif");
            this.imageList1.Images.SetKeyName(37, "Leaf-Queen.gif");
            this.imageList1.Images.SetKeyName(38, "Leaf-King.gif");
            this.imageList1.Images.SetKeyName(39, "Spade-1.gif");
            this.imageList1.Images.SetKeyName(40, "Spade-2.gif");
            this.imageList1.Images.SetKeyName(41, "Spade-3.gif");
            this.imageList1.Images.SetKeyName(42, "Spade-4.gif");
            this.imageList1.Images.SetKeyName(43, "Spade-5.gif");
            this.imageList1.Images.SetKeyName(44, "Spade-6.gif");
            this.imageList1.Images.SetKeyName(45, "Spade-7.gif");
            this.imageList1.Images.SetKeyName(46, "Spade-8.gif");
            this.imageList1.Images.SetKeyName(47, "Spade-9.gif");
            this.imageList1.Images.SetKeyName(48, "Spade-10.gif");
            this.imageList1.Images.SetKeyName(49, "Spade-Jack.gif");
            this.imageList1.Images.SetKeyName(50, "Spade-Queen.gif");
            this.imageList1.Images.SetKeyName(51, "Spade-King.gif");
            // 
            // btnDragaSpil
            // 
            this.btnDragaSpil.Location = new System.Drawing.Point(375, 479);
            this.btnDragaSpil.Name = "btnDragaSpil";
            this.btnDragaSpil.Size = new System.Drawing.Size(261, 58);
            this.btnDragaSpil.TabIndex = 0;
            this.btnDragaSpil.Text = "Draga Spil";
            this.btnDragaSpil.UseVisualStyleBackColor = true;
            this.btnDragaSpil.Click += new System.EventHandler(this.btnDragaSpil_Click);
            // 
            // panComputer
            // 
            this.panComputer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panComputer.Location = new System.Drawing.Point(715, 105);
            this.panComputer.Name = "panComputer";
            this.panComputer.Size = new System.Drawing.Size(261, 347);
            this.panComputer.TabIndex = 1;
            // 
            // panPlayer
            // 
            this.panPlayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panPlayer.Location = new System.Drawing.Point(46, 105);
            this.panPlayer.Name = "panPlayer";
            this.panPlayer.Size = new System.Drawing.Size(261, 347);
            this.panPlayer.TabIndex = 2;
            // 
            // btnRass
            // 
            this.btnRass.Image = global::Lokaverkefni.Properties.Resources.Malireinkun1;
            this.btnRass.Location = new System.Drawing.Point(880, 12);
            this.btnRass.Name = "btnRass";
            this.btnRass.Size = new System.Drawing.Size(96, 87);
            this.btnRass.TabIndex = 9;
            this.btnRass.Text = "Rass";
            this.btnRass.UseVisualStyleBackColor = true;
            this.btnRass.Click += new System.EventHandler(this.btnRass_Click);
            // 
            // btnMjolk
            // 
            this.btnMjolk.Image = global::Lokaverkefni.Properties.Resources.Mjolk1;
            this.btnMjolk.Location = new System.Drawing.Point(178, 12);
            this.btnMjolk.Name = "btnMjolk";
            this.btnMjolk.Size = new System.Drawing.Size(96, 87);
            this.btnMjolk.TabIndex = 8;
            this.btnMjolk.Text = "Mjólk";
            this.btnMjolk.UseVisualStyleBackColor = true;
            this.btnMjolk.Click += new System.EventHandler(this.btnMjolk_Click);
            // 
            // btnUll
            // 
            this.btnUll.Image = global::Lokaverkefni.Properties.Resources.Ullareinkun1;
            this.btnUll.Location = new System.Drawing.Point(305, 12);
            this.btnUll.Name = "btnUll";
            this.btnUll.Size = new System.Drawing.Size(91, 87);
            this.btnUll.TabIndex = 7;
            this.btnUll.Text = "Ull";
            this.btnUll.UseVisualStyleBackColor = true;
            this.btnUll.Click += new System.EventHandler(this.btnUll_Click);
            // 
            // btnAfkvaemi
            // 
            this.btnAfkvaemi.Image = global::Lokaverkefni.Properties.Resources.Afkvaemi1;
            this.btnAfkvaemi.Location = new System.Drawing.Point(418, 12);
            this.btnAfkvaemi.Name = "btnAfkvaemi";
            this.btnAfkvaemi.Size = new System.Drawing.Size(89, 87);
            this.btnAfkvaemi.TabIndex = 6;
            this.btnAfkvaemi.Text = "Afkvæmi";
            this.btnAfkvaemi.UseVisualStyleBackColor = true;
            this.btnAfkvaemi.Click += new System.EventHandler(this.btnAfkvaemi_Click);
            // 
            // btnLaeri
            // 
            this.btnLaeri.Image = global::Lokaverkefni.Properties.Resources.LærisEinkun2;
            this.btnLaeri.Location = new System.Drawing.Point(527, 12);
            this.btnLaeri.Name = "btnLaeri";
            this.btnLaeri.Size = new System.Drawing.Size(98, 87);
            this.btnLaeri.TabIndex = 5;
            this.btnLaeri.Text = "Læri";
            this.btnLaeri.UseVisualStyleBackColor = true;
            this.btnLaeri.Click += new System.EventHandler(this.btnLaeri_Click);
            // 
            // btnFrjosemi
            // 
            this.btnFrjosemi.Image = global::Lokaverkefni.Properties.Resources.Frjosemi1;
            this.btnFrjosemi.Location = new System.Drawing.Point(647, 12);
            this.btnFrjosemi.Name = "btnFrjosemi";
            this.btnFrjosemi.Size = new System.Drawing.Size(97, 87);
            this.btnFrjosemi.TabIndex = 4;
            this.btnFrjosemi.Text = "Frjósemi";
            this.btnFrjosemi.UseVisualStyleBackColor = true;
            this.btnFrjosemi.Click += new System.EventHandler(this.btnFrjosemi_Click);
            // 
            // btnHryggur
            // 
            this.btnHryggur.Image = global::Lokaverkefni.Properties.Resources.ÞykktBakvöðva2;
            this.btnHryggur.Location = new System.Drawing.Point(769, 12);
            this.btnHryggur.Name = "btnHryggur";
            this.btnHryggur.Size = new System.Drawing.Size(88, 87);
            this.btnHryggur.TabIndex = 3;
            this.btnHryggur.Text = "Hryggur";
            this.btnHryggur.UseVisualStyleBackColor = true;
            this.btnHryggur.Click += new System.EventHandler(this.btnHryggur_Click);
            // 
            // btnÞyngd
            // 
            this.btnÞyngd.Image = global::Lokaverkefni.Properties.Resources.Kiloþyngd1;
            this.btnÞyngd.Location = new System.Drawing.Point(46, 12);
            this.btnÞyngd.Name = "btnÞyngd";
            this.btnÞyngd.Size = new System.Drawing.Size(101, 87);
            this.btnÞyngd.TabIndex = 0;
            this.btnÞyngd.Text = "Þyngd";
            this.btnÞyngd.UseVisualStyleBackColor = true;
            this.btnÞyngd.Click += new System.EventHandler(this.btnÞyngd_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(342, 105);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(333, 198);
            this.richTextBox1.TabIndex = 10;
            this.richTextBox1.Text = "";
            // 
            // lblLeidbeiningar
            // 
            this.lblLeidbeiningar.AutoSize = true;
            this.lblLeidbeiningar.Location = new System.Drawing.Point(398, 324);
            this.lblLeidbeiningar.Name = "lblLeidbeiningar";
            this.lblLeidbeiningar.Size = new System.Drawing.Size(215, 13);
            this.lblLeidbeiningar.TabIndex = 11;
            this.lblLeidbeiningar.Text = "Dragðu spil og veldu svo flokk til að keppa í";
            // 
            // oneplayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1071, 579);
            this.Controls.Add(this.lblLeidbeiningar);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btnRass);
            this.Controls.Add(this.btnMjolk);
            this.Controls.Add(this.btnUll);
            this.Controls.Add(this.btnAfkvaemi);
            this.Controls.Add(this.btnLaeri);
            this.Controls.Add(this.btnFrjosemi);
            this.Controls.Add(this.btnHryggur);
            this.Controls.Add(this.btnÞyngd);
            this.Controls.Add(this.panPlayer);
            this.Controls.Add(this.panComputer);
            this.Controls.Add(this.btnDragaSpil);
            this.Name = "oneplayer";
            this.Text = " nvg";
            this.Load += new System.EventHandler(this.oneplayer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnDragaSpil;
        private System.Windows.Forms.Panel panComputer;
        private System.Windows.Forms.Panel panPlayer;
        private System.Windows.Forms.Button btnÞyngd;
        private System.Windows.Forms.Button btnHryggur;
        private System.Windows.Forms.Button btnFrjosemi;
        private System.Windows.Forms.Button btnLaeri;
        private System.Windows.Forms.Button btnAfkvaemi;
        private System.Windows.Forms.Button btnUll;
        private System.Windows.Forms.Button btnMjolk;
        private System.Windows.Forms.Button btnRass;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblLeidbeiningar;
    }
}