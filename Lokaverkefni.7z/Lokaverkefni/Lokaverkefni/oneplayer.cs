﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lokaverkefni
{
    public partial class oneplayer : Form
    {
        gagnagrunnur gagnagrunnur = new gagnagrunnur();

        int teljariSpil = 0;
        Random rand1 = new Random();
        List<int> spilari = new List<int>();
        List<int> tolva = new List<int>();
        List<int> stokkur = new List<int>();
        public oneplayer()
        {
            InitializeComponent();
            try
            {
                gagnagrunnur.TengingVidGagnagrunn();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void oneplayer_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 52; i++)
            {
                stokkur.Add(i); // Bæta við spili í stokk
            }
            while (stokkur.Count > 0) // Ef að stokkur er með meira en eitt spil
            {
                int randTala = rand1.Next(0, stokkur.Count); // Finnur eina tölu a milli 0 og fjölda spila í stokki (Dregur eitt spil úr stokknum af handahófi)

                if (teljariSpil %2 == 0) // Ef spilateljari er sletttala
	            {
		            spilari.Add(stokkur[randTala]); //Bæta við randTala úr stokki í hönd spilara
	            }

                else // Ef spilateljari er oddatala
                {
                    tolva.Add(stokkur[randTala]); //Bæta við randTala úr stokki í hönd tölvu
                }

                teljariSpil++; // Hækkar spilateljara
                stokkur.Remove(stokkur[randTala]); //Taka spil sem ad spilari eda tölva dró úr stokkinum
            }

        }//endir a void oneplayer 

        int tel = 0;

        private void btnDragaSpil_Click(object sender, EventArgs e)
        {
            
            panPlayer.BackgroundImage = imageList1.Images[spilari[tel]];
            string myndSpilara = imageList1.Images.Keys[spilari[tel]].ToString();
            panComputer.BackgroundImage = imageList1.Images[tolva[tel]];
            string myndTolvu = imageList1.Images.Keys[tolva[tel]].ToString();
            panComputer.Hide(); //felur mynd tolvu
            tel++;
            myndSpilara = myndSpilara.Substring(0, (myndSpilara.Length - 4));
            myndTolvu = myndTolvu.Substring(0, (myndTolvu.Length - 4));
            richTextBox1.Text = myndSpilara + "\n";
            richTextBox1.Text += myndTolvu;
        }


        /*ATH*/
        /*HER AD NEDAN MUN ATHUGA HVADA FLOKKUR VAR VALINN*/
        // int flokkur = 0; // ATHUGAR HVADA FLOKKUR VAR VALINN
        //þyngd
        List<string> hrutarID = new List<string>();
        string spilariGildi = null;
        string tolvaGildi = null;

        string[] spilariFlokkur;
        string[] tolvaFlokkur;
        private void btnÞyngd_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 3;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (þyngd)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " "+spilariFlokkur[3]+"\n"; //Tekur töluna sem er á eftir 3ja tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[3] + "\n"; //Tekur töluna sem er á eftir 3ja tvipunktinum.
	        }
            if (Convert.ToDouble(spilariFlokkur[3]) < Convert.ToDouble(tolvaFlokkur[3]))
            {
                MessageBox.Show("Spilari tapar"); // spilari tapar
            }
            else
            {
                MessageBox.Show("Spilari vinnur"); // spilari vinnur
            }

        }

        private void btnMjolk_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 4;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (Mjolk)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " " + spilariFlokkur[4] + "\n"; //Tekur töluna sem er á eftir 4 tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[4] + "\n"; //Tekur töluna sem er á eftir 4 tvipunktinum.
            }
            if (Convert.ToDouble(spilariFlokkur[4]) < Convert.ToDouble(tolvaFlokkur[4]))
            {
                MessageBox.Show("Spilari tapar"); // spilari tapar
            }
            else
            {
                MessageBox.Show("Spilari vinnur"); // spilari vinnur
            }
        }

        private void btnUll_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 5;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (Mjolk)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " " + spilariFlokkur[5] + "\n"; //Tekur töluna sem er á eftir 5 tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[5] + "\n"; //Tekur töluna sem er á eftir 5 tvipunktinum.
            }
            if (Convert.ToDouble(spilariFlokkur[5]) < Convert.ToDouble(tolvaFlokkur[5]))
            {
                MessageBox.Show("Spilari tapar"); // spilari tapar
            }
            else
            {
                MessageBox.Show("Spilari vinnur"); // spilari vinnur
            }
        }

        private void btnAfkvaemi_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 6;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (Mjolk)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " " + spilariFlokkur[6] + "\n"; //Tekur töluna sem er á eftir 6 tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[6] + "\n"; //Tekur töluna sem er á eftir 6 tvipunktinum.
            }
            if (Convert.ToDouble(spilariFlokkur[6]) < Convert.ToDouble(tolvaFlokkur[6]))
            {
                MessageBox.Show("Spilari tapar"); // spilari tapar
            }
            else
            {
                MessageBox.Show("Spilari vinnur"); // spilari vinnur
            }
        }

        private void btnLaeri_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 7;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (Mjolk)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " " + spilariFlokkur[7] + "\n"; //Tekur töluna sem er á eftir 7 tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[7] + "\n"; //Tekur töluna sem er á eftir 7 tvipunktinum.
            }
            if (Convert.ToDouble(spilariFlokkur[7]) < Convert.ToDouble(tolvaFlokkur[7]))
            {
                MessageBox.Show("Spilari tapar"); // spilari tapar
            }
            else
            {
                MessageBox.Show("Spilari vinnur"); // spilari vinnur
            }
        }

        private void btnFrjosemi_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 8;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (Mjolk)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " " + spilariFlokkur[8] + "\n"; //Tekur töluna sem er á eftir 8 tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[8] + "\n"; //Tekur töluna sem er á eftir 8 tvipunktinum.
            }
            if (Convert.ToDouble(spilariFlokkur[8]) < Convert.ToDouble(tolvaFlokkur[8]))
            {
                MessageBox.Show("Spilari tapar"); // spilari tapar
            }
            else
            {
                MessageBox.Show("Spilari vinnur"); // spilari vinnur
            }
        }

        private void btnHryggur_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 9;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (Mjolk)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " " + spilariFlokkur[9] + "\n"; //Tekur töluna sem er á eftir 9 tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[9] + "\n"; //Tekur töluna sem er á eftir 9 tvipunktinum.
            }
            if (Convert.ToDouble(spilariFlokkur[9]) < Convert.ToDouble(tolvaFlokkur[9]))
            {
                MessageBox.Show("Spilari tapar"); // spilari tapar
            }
            else
            {
                MessageBox.Show("Spilari vinnur"); // spilari vinnur
            }
        }

        private void btnRass_Click(object sender, EventArgs e)
        {
            panComputer.Show(); // sýnir mynd tolvu
            //flokkur = 10;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            spilariGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[spilari[tel - 1]]));
            tolvaGildi = gagnagrunnur.LesautSQLFlokk(Convert.ToInt32(hrutarID[tolva[tel - 1]]));
            spilariFlokkur = spilariGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            tolvaFlokkur = tolvaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (Mjolk)
            {
                richTextBox1.Text = "\n";
                richTextBox1.Text += x + " " + spilariFlokkur[10] + "\n"; //Tekur töluna sem er á eftir 10 tvipunktinum.
                richTextBox1.Text += x + " " + tolvaFlokkur[10] + "\n"; //Tekur töluna sem er á eftir 10 tvipunktinum.

            }
            if (Convert.ToDouble(spilariFlokkur[10]) < Convert.ToDouble(tolvaFlokkur[10]))
            {
                MessageBox.Show("eythor er med litid typpi"); // spilari tapar
            }
            else
            {
                MessageBox.Show("eythor er med uber litid typpi"); // spilari vinnur
            }
        }


 
        
            
       
    }// endir a form
}
