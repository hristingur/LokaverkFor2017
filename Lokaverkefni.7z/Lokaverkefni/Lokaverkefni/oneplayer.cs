﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lokaverkefni
{
    public partial class oneplayer : Form
    {
        gagnagrunnur gagnagrunnur = new gagnagrunnur();

        int teljariSpil = 0;
        Random rand1 = new Random();
        List<int> spilari = new List<int>();
        List<int> tolva = new List<int>();
        List<int> stokkur = new List<int>();
        public oneplayer()
        {
            InitializeComponent();
            try
            {
                gagnagrunnur.TengingVidGagnagrunn();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void oneplayer_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 52; i++)
            {
                stokkur.Add(i); // Bæta við spili í stokk
            }
            while (stokkur.Count > 0) // Ef að stokkur er með meira en eitt spil
            {
                int randTala = rand1.Next(0, stokkur.Count); // Finnur eina tölu a milli 0 og fjölda spila í stokki (Dregur eitt spil úr stokknum af handahófi)

                if (teljariSpil %2 == 0) // Ef spilateljari er sletttala
	            {
		            spilari.Add(stokkur[randTala]); //Bæta við randTala úr stokki í hönd spilara
	            }

                else // Ef spilateljari er oddatala
                {
                    tolva.Add(stokkur[randTala]); //Bæta við randTala úr stokki í hönd tölvu
                }

                teljariSpil++; // Hækkar spilateljara
                stokkur.Remove(stokkur[randTala]); //Taka spil sem ad spilari eda tölva dró úr stokkinum
            }

        }//endir a void oneplayer 

        int tel = 0;

        private void btnDragaSpil_Click(object sender, EventArgs e)
        {
            
            panPlayer.BackgroundImage = imageList1.Images[spilari[tel]];
            string myndSpilara = imageList1.Images.Keys[spilari[tel]].ToString();
            panComputer.BackgroundImage = imageList1.Images[tolva[tel]];
            string myndTolvu = imageList1.Images.Keys[tolva[tel]].ToString();
            tel++;
            myndSpilara = myndSpilara.Substring(0, (myndSpilara.Length - 4));
            myndTolvu = myndTolvu.Substring(0, (myndTolvu.Length - 4));
            richTextBox1.Text = myndSpilara + "\n";
            richTextBox1.Text += myndTolvu;
        }


        /*ATH*/
        /*HER AD NEDAN MUN ATHUGA HVADA FLOKKUR VAR VALINN*/
        // int flokkur = 0; // ATHUGAR HVADA FLOKKUR VAR VALINN
        //þyngd
        List<string> hrutarID = new List<string>();
        string flokkaGildi = null;
        private void btnÞyngd_Click(object sender, EventArgs e)
        {
            //flokkur = 3;
            hrutarID = gagnagrunnur.GetID(); // tekur oll id's ur SQL og setur i lista
            flokkaGildi = gagnagrunnur.LesautSQLWeight(Convert.ToInt32( hrutarID[spilari[tel-1]]));
            string[] flokkur;
            flokkur = flokkaGildi.Split(':'); // breytir einum streng i marga strengi midad vid hvada staf eda merki er valid (Strengur0:Strengur1:Strengur2) 0 1 2
            foreach (var x in hrutarID)// fyrir hvert x i konni (þyngd)
	        {
                richTextBox1.Text += x + " "+flokkur[3]+"\n"; //Tekur töluna sem er á eftir 3ja tvipunktinum.
	        }

        }

        
            
       
    }// endir a form
}
